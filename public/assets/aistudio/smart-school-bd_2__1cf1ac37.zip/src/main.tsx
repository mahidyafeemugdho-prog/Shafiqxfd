import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/common/ErrorBoundary.tsx';
import './index.css';

// Global Browser Error Shield for AI Studio Preview Environment
// Prevents non-fatal browser warnings (TTS interruptions, camera permission prompts, ResizeObserver)
// from propagating as runtime breakages to the outer host container.
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    const msg = event?.message || '';
    if (
      msg.includes('ResizeObserver') ||
      msg.includes('SpeechSynthesis') ||
      msg.includes('synthesis') ||
      msg.includes('NotAllowedError') ||
      msg.includes('Permission denied') ||
      msg.includes('Camera') ||
      msg.includes('media') ||
      msg.includes('AudioContext')
    ) {
      event.preventDefault();
      event.stopPropagation();
      return true;
    }
  });

  window.addEventListener('unhandledrejection', (event) => {
    const reason = String(event?.reason || '');
    if (
      reason.includes('NotAllowedError') ||
      reason.includes('Permission denied') ||
      reason.includes('SpeechSynthesis') ||
      reason.includes('canceled') ||
      reason.includes('interrupted') ||
      reason.includes('abort') ||
      reason.includes('AudioContext')
    ) {
      event.preventDefault();
      event.stopPropagation();
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
