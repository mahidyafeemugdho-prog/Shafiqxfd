import React, { useState, useEffect } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { SchoolProvider } from './context/SchoolContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { HeroLoginView } from './components/auth/HeroLoginView';

// View Components
import { DashboardView } from './components/dashboard/DashboardView';
import { StudentsView } from './components/students/StudentsView';
import { StaffView } from './components/staff/StaffView';
import { AttendanceView } from './components/attendance/AttendanceView';
import { SmartQRScannerTab } from './components/attendance/SmartQRScannerTab';
import { AcademicView } from './components/academic/AcademicView';
import { RoutineView } from './components/routine/RoutineView';
import { ExaminationsView } from './components/examinations/ExaminationsView';
import { FeesView } from './components/fees/FeesView';
import { HomeworkView } from './components/homework/HomeworkView';
import { AdmissionsView } from './components/admissions/AdmissionsView';
import { LibraryView } from './components/library/LibraryView';
import { TransportView } from './components/transport/TransportView';
import { InventoryView } from './components/inventory/InventoryView';
import { CertificatesView } from './components/certificates/CertificatesView';
import { NoticesView } from './components/notices/NoticesView';
import { BlogManagementView } from './components/blog/BlogManagementView';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { MasterAdminPortal } from './components/master/MasterAdminPortal';
import { StudentPerformanceAnalyticsView } from './components/analytics/StudentPerformanceAnalyticsView';
import { isTabAuthorized } from './utils/permissions';
import { CloudSyncService } from './services/cloudSync';

const AppContent: React.FC = () => {
  const { isAuthenticated, activeRole, currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<string>(() => {
    return activeRole === 'master_admin' ? 'master_portal' : 'dashboard';
  });
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [cloudSyncRevision, setCloudSyncRevision] = useState<number>(0);

  // Initialize real-time Cloud Synchronization with Firebase Firestore
  useEffect(() => {
    const cleanup = CloudSyncService.initialize();
    const handleSync = () => {
      setCloudSyncRevision((prev) => prev + 1);
    };
    window.addEventListener('school_cloud_data_synced', handleSync);
    return () => {
      cleanup();
      window.removeEventListener('school_cloud_data_synced', handleSync);
    };
  }, []);

  // Sync activeTab when role changes
  useEffect(() => {
    if (activeRole === 'gatekeeper' || currentUser?.permissions?.onlyQrAttendanceKiosk) {
      if (activeTab !== 'qr_attendance') {
        setActiveTab('qr_attendance');
      }
    } else if (activeRole === 'student') {
      setActiveTab('dashboard');
    } else if (activeRole === 'master_admin') {
      if (activeTab !== 'master_portal' && !isTabAuthorized(activeTab, activeRole, currentUser)) {
        setActiveTab('master_portal');
      }
    } else {
      if (activeTab === 'master_portal' || !isTabAuthorized(activeTab, activeRole, currentUser)) {
        setActiveTab('dashboard');
      }
    }
  }, [activeRole, currentUser, activeTab]);

  if (!isAuthenticated) {
    return (
      <div key={cloudSyncRevision}>
        <HeroLoginView />
      </div>
    );
  }

  const renderActiveView = () => {
    switch (activeTab) {
      case 'master_portal':
        return <MasterAdminPortal />;
      case 'dashboard':
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} />;
      case 'students':
        return <StudentsView onPrintCertificate={() => setActiveTab('certificates')} />;
      case 'staff':
        return <StaffView />;
      case 'attendance':
        return <AttendanceView />;
      case 'qr_attendance':
        return (
          <div className={isAttendanceOnly ? "w-full h-full -m-3 sm:-m-5 lg:-m-6" : "space-y-6"}>
            <SmartQRScannerTab
              isGatekeeper={isAttendanceOnly}
              onAttendanceUpdated={() => {
                setCloudSyncRevision((prev) => prev + 1);
              }}
            />
          </div>
        );
      case 'academic':
        return <AcademicView />;
      case 'routine':
        return <RoutineView />;
      case 'examinations':
        return <ExaminationsView />;
      case 'fees':
        return <FeesView />;
      case 'homework':
        return <HomeworkView />;
      case 'admissions':
        return <AdmissionsView />;
      case 'library':
        return <LibraryView />;
      case 'transport':
        return <TransportView />;
      case 'inventory':
        return <InventoryView />;
      case 'certificates':
        return <CertificatesView />;
      case 'notices':
        return <NoticesView />;
      case 'blog':
        return <BlogManagementView />;
      case 'reports':
        return <ReportsView />;
      case 'analytics':
        return <StudentPerformanceAnalyticsView />;
      case 'settings':
        return <SettingsView />;
      case 'website_preview':
        return (
          <div className="relative -m-3 sm:-m-5 lg:-m-6">
            <div className="sticky top-0 z-50 bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between text-xs shadow-md border-b border-slate-700">
              <span className="font-bold flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>পাবলিক ওয়েবসাইট ও হিরো সেকশন প্রিভিউ (Public Website Preview)</span>
              </span>
              <button
                onClick={() => setActiveTab('dashboard')}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold shadow-xs transition-colors"
              >
                ← ড্যাশবোর্ডে ফিরে যান (Back to ERP)
              </button>
            </div>
            <HeroLoginView />
          </div>
        );
      default:
        return <DashboardView onNavigate={(tab) => setActiveTab(tab)} />;
    }
  };

  // Attendance Kiosk operator lockdown check
  const isAttendanceOnly = activeRole === 'gatekeeper' || !!currentUser?.permissions?.onlyQrAttendanceKiosk;

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden font-sans">
      {/* Sidebar Navigation (Hidden for Student Portal and Attendance-Only Kiosk Operators) */}
      {!isAttendanceOnly && activeRole !== 'student' && (
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
          activeTab={activeTab}
          onNavigate={(tab) => setActiveTab(tab)}
        />
        <main className={`flex-1 overflow-y-auto ${isAttendanceOnly ? 'p-1 sm:p-2 bg-slate-950' : 'p-3 sm:p-5 lg:p-6 bg-slate-50/70'}`}>
          <div className={isAttendanceOnly ? "w-full max-w-full" : "max-w-7xl mx-auto"} key={cloudSyncRevision}>
            {renderActiveView()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <LanguageProvider>
        <SchoolProvider>
          <AuthProvider>
            <AppContent />
          </AuthProvider>
        </SchoolProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}
